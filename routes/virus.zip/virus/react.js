import React, { useState, useEffect } from 'react';
import axios from 'axios';

const App = () => {
  const [users, setUsers] = useState([]);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [userForm, setUserForm] = useState({
    name: '',
    email: '',
    phone: '',
    age: '',
    profilePic: null
  });

  useEffect(() => {
    axios.get(`http://localhost:5000/users?page=${page}`)
      .then(response => {
        setUsers(response.data.users);
        setTotalPages(response.data.totalPages);
      })
      .catch(error => console.error(error));
  }, [page]);

  const handleFormChange = (e) => {
    const { name, value } = e.target;
    setUserForm({ ...userForm, [name]: value });
  };

  const handleFileChange = (e) => {
    setUserForm({ ...userForm, profilePic: e.target.files[0] });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append('name', userForm.name);
    formData.append('email', userForm.email);
    formData.append('phone', userForm.phone);
    formData.append('age', userForm.age);
    if (userForm.profilePic) {
      formData.append('profilePic', userForm.profilePic);
    }

    axios.post('http://localhost:5000/user', formData)
      .then(response => {
        setUsers([...users, response.data]);
        setUserForm({
          name: '',
          email: '',
          phone: '',
          age: '',
          profilePic: null
        });
      })
      .catch(error => console.error(error));
  };

  const handleDelete = (id) => {
    axios.delete(`http://localhost:5000/user/${id}`)
      .then(() => {
        setUsers(users.filter(user => user._id !== id));
      })
      .catch(error => console.error(error));
  };

  const handleUpdate = (id) => {
    const user = users.find(user => user._id === id);
    setUserForm(user);
  };

  return (
    <div>
      <h1>User Management</h1>
      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Name" value={userForm.name} onChange={handleFormChange} required />
        <input type="email" name="email" placeholder="Email" value={userForm.email} onChange={handleFormChange} required />
        <input type="text" name="phone" placeholder="Phone" value={userForm.phone} onChange={handleFormChange} required />
        <input type="number" name="age" placeholder="Age" value={userForm.age} onChange={handleFormChange} required />
        <input type="file" name="profilePic" onChange={handleFileChange} />
        <button type="submit">Add User</button>
      </form>

      <h2>User List</h2>
      <ul>
        {users.map(user => (
          <li key={user._id}>
            <img src={`http://localhost:5000/${user.profilePic}`} alt="Profile" width="50" />
            {user.name} - {user.email} - {user.phone} - {user.age}
            <button onClick={() => handleUpdate(user._id)}>Update</button>
            <button onClick={() => handleDelete(user._id)}>Delete</button>
          </li>
        ))}
      </ul>

      <div>
        <button onClick={() => setPage(page > 1 ? page - 1 : 1)}>Previous</button>
        <span> Page {page} of {totalPages} </span>
        <button onClick={() => setPage(page < totalPages ? page + 1 : totalPages)}>Next</button>
      </div>
    </div>
  );
};

export default App;



// for chat
// src/Chat.js
import React, { useState, useEffect } from 'react';
import io from 'socket.io-client';

const socket = io('http://localhost:5000'); // Connect to the backend server

const Chat = () => {
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState([]);
  const [user, setUser] = useState('');

  // Listen for incoming messages
  useEffect(() => {
    socket.on('receive_message', (messageData) => {
      setMessages((prevMessages) => [...prevMessages, messageData]);
    });

    // Clean up on unmount
    return () => {
      socket.off('receive_message');
    };
  }, []);

  // Handle sending a message
  const sendMessage = () => {
    if (message.trim() !== '') {
      const messageData = {
        user,
        message,
        timestamp: new Date().toLocaleTimeString(),
      };

      socket.emit('send_message', messageData); // Emit the message to the server
      setMessages((prevMessages) => [...prevMessages, messageData]); // Add message locally
      setMessage(''); // Clear the input field
    }
  };

  return (
    <div>
      <h1>Real-Time Chat</h1>

      {/* User input */}
      {!user && (
        <div>
          <input
            type="text"
            placeholder="Enter your name"
            value={user}
            onChange={(e) => setUser(e.target.value)}
          />
        </div>
      )}

      {/* Chat messages */}
      <div style={{ height: '300px', overflowY: 'scroll', border: '1px solid #ccc', padding: '10px' }}>
        {messages.map((msg, index) => (
          <div key={index}>
            <strong>{msg.user}</strong>: {msg.message} <small>{msg.timestamp}</small>
          </div>
        ))}
      </div>

      {/* Message input */}
      <div>
        <input
          type="text"
          placeholder="Type a message"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
        />
        <button onClick={sendMessage}>Send</button>
      </div>
    </div>
  );
};

export default Chat;
