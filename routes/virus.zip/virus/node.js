const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const multer = require('multer');
const path = require('path');

const app = express();

// Middleware
app.use(express.json());
app.use(cors());

// MongoDB Connection
mongoose.connect('mongodb://localhost:27017/usercrud', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => console.log("MongoDB connected"))
  .catch(err => console.log(err));

// Define the User Schema
const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String, required: true },
  age: { type: Number, required: true },
  profilePic: { type: String },
});

const User = mongoose.model('User', userSchema);

// Set up file upload with multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, 'uploads/');
  },
  filename: (req, file, cb) => {
    cb(null, Date.now() + path.extname(file.originalname));
  }
});

const upload = multer({ storage: storage });

// Routes
app.post('/user', upload.single('profilePic'), async (req, res) => {
  const { name, email, phone, age } = req.body;
  const profilePic = req.file ? req.file.path : '';

  const user = new User({ name, email, phone, age, profilePic });
  await user.save();
  res.status(201).send(user);
});

app.get('/users', async (req, res) => {
  const page = parseInt(req.query.page) || 1;
  const limit = 5;
  const skip = (page - 1) * limit;

  const users = await User.find().skip(skip).limit(limit);
  const totalUsers = await User.countDocuments();

  res.json({
    users,
    totalPages: Math.ceil(totalUsers / limit),
    currentPage: page
  });
});

app.get('/user/:id', async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) {
    return res.status(404).send('User not found');
  }
  res.json(user);
});

app.put('/user/:id', upload.single('profilePic'), async (req, res) => {
  const { name, email, phone, age } = req.body;
  const profilePic = req.file ? req.file.path : undefined;

  const user = await User.findByIdAndUpdate(
    req.params.id,
    { name, email, phone, age, profilePic },
    { new: true }
  );

  if (!user) {
    return res.status(404).send('User not found');
  }

  res.json(user);
});

app.delete('/user/:id', async (req, res) => {
  const user = await User.findByIdAndDelete(req.params.id);
  if (!user) {
    return res.status(404).send('User not found');
  }
  res.json({ message: 'User deleted successfully' });
});

// Start the server
app.listen(5000, () => {
  console.log('Server running on port 5000');
});








//node chat

// server.js
const express = require('express');
const http = require('http');
const socketIo = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Serve static files from the React app (optional, if you want to serve the React app from the same server)
app.use(express.static('client/build'));

// Socket.io functionality for real-time communication
io.on('connection', (socket) => {
  console.log('a user connected');

  // Listen for incoming messages
  socket.on('send_message', (messageData) => {
    console.log('Message received:', messageData);
    // Emit the message to all connected clients
    io.emit('receive_message', messageData);
  });

  // Handle disconnect
  socket.on('disconnect', () => {
    console.log('a user disconnected');
  });
});

// Start the server on port 5000
server.listen(5000, () => {
  console.log('Server running on http://localhost:5000');
});



//joins 

// Using MongoDB's aggregation framework to join Users and Posts collections
db.posts.aggregate([
  {
    $lookup: {
      from: "users", // The collection to join (Users)
      localField: "userId", // Field from the current collection (Posts) to match
      foreignField: "_id", // Field from the "users" collection to match against
      as: "userDetails" // The result will be returned in this field
    }
  },
  {
    $unwind: "$userDetails" // Flatten the userDetails array (because $lookup returns an array)
  },
  {
    $project: {
      title: 1,
      content: 1,
      "userDetails.name": 1, // Select the fields you want from the "userDetails"
      "userDetails.email": 1
    }
  }
])
